const express = require('express');

const post = express.Router();

const {fileList} = require('../src/js/fileList')

post.get('/', (req, res) => {
    let newFile = fileList;
    console.log(newFile);
    res.render('post.art', {
        fileList
    });
})

post.get('/src/html', (req, res) => {
    let address = req.query.name + ".art"
    //res.send(address)
    res.render('../src/html/'+address);
})

module.exports = post;