===
Title: When 531 People Do Good
Author: Jon Hollingsworth
Slug: people-do-good
===
# When 531 People Do Good
Of the 634 people who held an orange Lego brick in their hand yesterday, **531** of them cared enough to give it back.

Those 531 people made a conscious decision to make sure it got to the right place. They decided that making a quick detour to our [Canterbury Tech Summit](http://www.techsummit.nz/) booth was worth it.

This year, Summit-goers showed us we were right to put our faith in people. In the end, 84% of attendees decided to do the right thing.

For those who don’t know, at the Tech Summit this year (just like last year), we opted out of swag bags, and opted in to giving.