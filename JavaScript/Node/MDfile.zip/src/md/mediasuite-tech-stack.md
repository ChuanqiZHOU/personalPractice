===
Title: Media Suite Tech Stack
Author: Ewen Cumming
Slug: mediasuite-tech-stack
===
# Technologies we use
Here at Media Suite we use a range of technologies for our web applications.  Many of our large bespoke projects typically use either Loopback or Django on the server, and [Ember](https://www.emberjs.com/), React or Angular on the client. However, we also have a large number of exciting projects that make use of SilverStripe, a PHP framework designed and built right here in New Zealand.