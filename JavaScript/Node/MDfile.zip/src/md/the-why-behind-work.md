===
Title: The Why Behind Work
Author: Steve Liew
Slug: the-why-behind-work
===
If your only reason for coming to work is to earn some money, then you're missing an opportunity.

Your job should be **fulfilling**<sup>1</sup>

----
1. And fun, and stimulating, and rewarding.  In both senses.